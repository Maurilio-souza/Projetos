const express = require("express");
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.urlencoded({extended: true}));

app.listen(8000, () => {
    console.log("Servidor Aberto")
});

app.get("/", (req, res) => {
    res.send("Olá Boa Noite!")
});

app.post("/", (req, res) => {
console.log(req.body)
res.send("Olá Obrigado pela reserva " + req.body.nome)
});